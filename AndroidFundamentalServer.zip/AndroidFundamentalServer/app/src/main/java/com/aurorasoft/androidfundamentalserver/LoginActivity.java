package com.aurorasoft.androidfundamentalserver;

import android.annotation.SuppressLint;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class LoginActivity extends AppCompatActivity {

    ProgressDialog pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        hide();

        pd = new ProgressDialog(LoginActivity.this);

        final Button btLogin = (Button)findViewById(R.id.bt_login);
        final EditText etUsername = (EditText)findViewById(R.id.et_username);
        final EditText etPassword = (EditText)findViewById(R.id.et_password);

        btLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pd.setTitle("Loading...");
                pd.setMessage("User Data...");
                pd.show();

                String u = etUsername.getText().toString();
                String p = etPassword.getText().toString();

                RequestQueue queue = Volley.newRequestQueue(getBaseContext());
                String url = "http://aurorasoft.my.id/mahasiswa/login.php?action=1&username="+ u +"&password="+ p;

                Log.i("get seafood ", "load: " + url);
                JsonObjectRequest jsObjRequest = new JsonObjectRequest(
                        Request.Method.GET,
                        url,
                        null,
                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject response) {
                                Log.d("rendi: ", response.toString());

                                String status = response.optString("status").trim();
                                if(status.equals("0")){
                                    Toast.makeText(getBaseContext(),"Login Process Failed",Toast.LENGTH_SHORT).show();
                                } else if (status.equals("1")){
                                    Intent i = new Intent(getBaseContext(),MainActivity.class);
                                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                    getBaseContext().startActivity(i);
                                }

                                if (pd.isShowing()) pd.dismiss();
//
                            }
                        }, new Response.ErrorListener() {

                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // TODO Auto-generated method stub
                        Log.d("login: ", error.toString());
                        if (pd.isShowing()) pd.dismiss();
                        Toast.makeText(getBaseContext(), "Please check your connection", Toast.LENGTH_SHORT).show();
                    }
                });

                queue.add(jsObjRequest);
            }
        });

      }

    private void hide() {
        // Hide UI first
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.hide();
        }
    }
}
